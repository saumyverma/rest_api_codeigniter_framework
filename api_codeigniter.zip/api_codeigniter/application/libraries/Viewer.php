<?php

class viewer {

    private $ci;
    public function __construct() {
        $this->ci = & get_instance();
    }
    public function fview($view, $data = array(), $layout = TRUE) {
        if ($layout == FALSE) {
            $this->ci->load->view('front/' . $view, $data);
        } else {
            $data['content'] = $this->ci->load->view('front/' . $view, $data, TRUE);
            $this->ci->load->view('front/includes/layout.php', $data);
        }
    }
    public function aview($view, $data = array(), $layout = TRUE) {
        if ($layout == FALSE) {
            $this->ci->load->view('admin/' . $view, $data);
        } else {
         
            $data['content'] = $this->ci->load->view('admin/' . $view, $data, TRUE);
            $this->ci->load->view('admin/includes/layout.php', $data);
        }
    }
    public function uview($view, $data = array(), $layout = TRUE) {
        if ($layout == FALSE) {
            $this->ci->load->view('user/' . $view, $data);
        } else {
            $data['content'] = $this->ci->load->view('user/' . $view, $data, TRUE);
            $this->ci->load->view('user/includes/layout.php', $data);
        }
    }
    
     public function error_view($view, $data = array(), $layout = TRUE) {
        if ($layout == FALSE) {
            $this->ci->load->view('errors/' . $view, $data);
        } else {
            $data['content'] = $this->ci->load->view('user/' . $view, $data, TRUE);
            $this->ci->load->view('user/includes/layout.php', $data);
        }
    }

}

?>
