<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

function varify_session() {
    $CI = &get_instance();
    if (!$CI->session->userdata('logged_in')) {
        redirect(base_url());
    }
}

function getFoundRows() {
    $CI = &get_instance();
    $c = $CI->db->query("SELECT FOUND_ROWS() as cnt");
    $fnd = $c->result_array($c);
    return $fnd[0]['cnt'];
}


function getEmailConfig() {
    $config['protocol'] = 'smtp';
    $config['smtp_host'] = MAIL_HOST;
    $config['smtp_user'] = MAIL_USER;
    $config['smtp_pass'] = MAIL_PASSWORD;
    $config['smtp_port'] = 25;
    $config['useragent'] = MAIL_AGENT;
    $config['mailtype'] = "html";

    return $config;
}

function EmailConfig() {
    $config['protocol'] = 'sendmail';
    $config['mailpath'] = '/usr/sbin/sendmail';
    $config['charset'] = 'iso-8859-1';
    $config['wordwrap'] = TRUE;
    $config['mailtype'] = "html";

    return $config;
}

function randomString($length = 6) {
    $str = '23456789abcdefghjkmnpqrstuvwxyz';
    $rstr = '';
    for ($i = 0; $i < $length; $i++) {
        $rstr .= $str[rand(0, strlen($str) - 1)];
    }
    return $rstr;
}

function randomNumber($length = 6) {
    $str = '123456789';
    $rstr = '';
    for ($i = 0; $i < $length; $i++) {
        $rstr .= $str[rand(0, strlen($str) - 1)];
    }
    return $rstr;
}

function wordLimiter($text, $limit = 100) {
    $explode = explode(' ', $text);
    $string = '';
    $i = 0;
    while ($i < count($explode)) {

        $string .= $explode[$i++] . " ";
        if (strlen($string) >= $limit) {
            break;
        }
    }
    $dots = (strlen($text) <= $limit) ? '' : '...';
    return $string . $dots;
}

function debug($data) {
    echo '<pre>';
    print_r($data);
    echo '</pre>';
}

function dmyToYmd($old_date) {
    list($d, $m, $y) = explode('/', $old_date);
    $new_date = "$y-$m-$d";
    return $new_date;
}

function YmdToDmy($old_date) {
    list($y, $m, $d) = explode('-', $old_date);
    $new_date = "$d/$m/$y";
    return $new_date;
}

function YmdToSdmy($old_date) {
    $cls_date = new DateTime($old_date);
    return $cls_date->format('d,M Y');
}

function getTimestamp($dateonly = false) {
    $timezone = "Asia/Calcutta";
    if (function_exists('date_default_timezone_set'))
        date_default_timezone_set($timezone);
    if ($dateonly) {
        return date('Y-m-d');
    } else {
        return date('Y-m-d H:i:s');
    }
}

function nearestTime($time = '') {
    $timezone = "Asia/Calcutta";
    if (function_exists('date_default_timezone_set'))
        date_default_timezone_set($timezone);
    if ($time == "") {
        $time = time();
    }
    $round = 30 * 60;
    $rounded = ceil($time / $round) * $round;
    return date("h:i A", $rounded);
}

function parseAddress($street, $city, $state, $country, $zip = "") {
    $address = "";
    if (trim($street) != "") {
        $address .= trim($street);
    }
    if (trim($city) != "") {
        if (trim($street) != "") {
            $address .= ', ';
        } $address .= trim($city);
    }
    if (trim($state) != "") {
        if (trim($city) != "") {
            $address .= ', ';
        } $address .= trim($state);
    }
    if (trim($country) != "") {
        if (trim($state) != "") {
            $address .= ', ';
        } $address .= trim($country);
    }
    if (trim($zip) != "") {
        if (trim($country) != "") {
            $address .= '- ';
        } $address .= trim($zip);
    }
    return $address;
}

function getPaginationFooter($cur_page, $per_page, $count) {
    $previous_btn = true;
    $next_btn = true;
    $first_btn = false;
    $last_btn = false;
    $msg = "";
    $no_of_paginations = ceil($count / $per_page);
    if ($cur_page >= 7) {
        $start_loop = $cur_page - 3;
        if ($no_of_paginations > $cur_page + 3)
            $end_loop = $cur_page + 3;
        else if ($cur_page <= $no_of_paginations && $cur_page >
                $no_of_paginations - 6) {
            $start_loop = $no_of_paginations - 6;
            $end_loop = $no_of_paginations;
        } else {
            $end_loop = $no_of_paginations;
        }
    } else {
        $start_loop = 1;
        if ($no_of_paginations > 7)
            $end_loop = 7;
        else
            $end_loop = $no_of_paginations;
    }
    if ($count >
            0) {
        $total_string = "<div class='row'><div class='col-md-4' a='$no_of_paginations'><div style='margin-top:10px;'>Page <b>" . $cur_page . "</b> of <b>$no_of_paginations</b> Pages &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Total Records <strong>" . $count . "</strong></div></div>";
        $msg .= $total_string . "<div class='col-md-8' style='margin-top:-5px;'><nav aria-label='Page navigation example'>"
                . " <ul class='pagination justify-content-end pull-right'>";
        // FOR ENABLING THE FIRST BUTTON
        if ($first_btn && $cur_page > 1) {
            $msg .= "<li p='1' class='page-item disabled'><span class='page-link' style='cursor:pointer'>First</span></li>";
        } else if ($first_btn) {
            $msg .= "<li p='1'  class='page-item active'><span class='page-link' style='cursor:pointer'>First</span></li>";
        }
        // FOR ENABLING THE PREVIOUS BUTTON
        if ($previous_btn && $cur_page > 1) {
            $pre = $cur_page - 1;
            $msg .= "<li p='$pre' class='page-item disabled' style='cursor:pointer'><span class='page-link' style='cursor:pointer'> ← Prev</span></li>";
        } else if ($previous_btn) {
            $msg .= "<li class='page-item active' style='cursor:pointer'><span class='page-link' style='cursor:pointer'> ← Prev</span></li>";
        }
        for ($i = $start_loop; $i <= $end_loop; $i++) {
            if ($cur_page == $i) {
                $msg .= "<li p='$i' style='color:#fff;background-color:#46A70C; cursor:pointer;' class='page-item active'><span class='page-link' style='cursor:pointer'>
    $i</span></li>";
            } else {
                $msg .= "<li p='$i'class='page-item inactive' style='cursor:pointer'><span class='page-link' style='cursor:pointer'>$i</span></li>";
            }
        }
        // TO ENABLE THE NEXT BUTTON
        if ($next_btn && $cur_page < $no_of_paginations) {
            $nex = $cur_page + 1;
            $msg .= "<li p='$nex' class='page-item inactive'><span class='page-link' style='cursor:pointer'> Next →</span></li>";
        } else if ($next_btn) {
            $msg .= "<li class='page-item active'><span class='page-link' style='cursor:pointer'>Next → </span></li>";
        }
// TO ENABLE THE END BUTTON
        if ($last_btn && $cur_page < $no_of_paginations) {
            $msg .= "<li p='$no_of_paginations' class='page-item inactive' style='cursor:pointer'><span class='page-link' style='cursor:pointer'>Last</span></li>";
        } else if ($last_btn) {
            $msg .= "<li p='$no_of_paginations' class='page-item active' style='cursor:pointer'><span class='page-link' style='cursor:pointer'>Last</span></li>";
        }
        $msg = $msg . "</ul></nav></div></div><div class='clearfix'></div>";
     
        return $msg;
    }
}

function getPagination($cur_page, $per_page, $count) {
    $previous_btn = true;
    $next_btn = true;
    $first_btn = false;
    $last_btn = false;
    $msg = "";
    $no_of_paginations = ceil($count / $per_page);
    if ($cur_page >= 7) {
        $start_loop = $cur_page - 3;
        if ($no_of_paginations > $cur_page + 3)
            $end_loop = $cur_page + 3;
        else if ($cur_page <= $no_of_paginations && $cur_page >
                $no_of_paginations - 6) {
            $start_loop = $no_of_paginations - 6;
            $end_loop = $no_of_paginations;
        } else {
            $end_loop = $no_of_paginations;
        }
    } else {
        $start_loop = 1;
        if ($no_of_paginations > 7)
            $end_loop = 7;
        else
            $end_loop = $no_of_paginations;
    }
    if ($count >
            0) {
        $total_string = "<div class='row'><div class='col-md-4' a='$no_of_paginations'><div style='margin-top:10px;'>Page <b>" . $cur_page . "</b> of <b>$no_of_paginations</b> Pages &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Total Records <strong>" . $count . "</strong></div></div>";
        $msg .= $total_string . "<div class='col-md-8' style='margin-top:-5px;'>"
                . "<ul class='pagination pull-right'>";
        // FOR ENABLING THE FIRST BUTTON
        if ($first_btn && $cur_page > 1) {
            $msg .= "<li p='1' class='inactive' style='cursor:pointer'><span style='cursor:pointer'>First</span></li>";
        } else if ($first_btn) {
            $msg .= "<li p='1' class='active' style='cursor:pointer'><span style='cursor:pointer'>First</span></li>";
        }
        // FOR ENABLING THE PREVIOUS BUTTON
        if ($previous_btn && $cur_page > 1) {
            $pre = $cur_page - 1;
            $msg .= "<li p='$pre' class='inactive' style='cursor:pointer'><span style='cursor:pointer'> ← Prev</span></li>";
        } else if ($previous_btn) {
            $msg .= "<li class='active' style='cursor:pointer'><span style='cursor:pointer'> ← Prev</span></li>";
        }
        for ($i = $start_loop; $i <= $end_loop; $i++) {
            if ($cur_page == $i) {
                $msg .= "<li p='$i' style='color:#fff;background-color:#46A70C; cursor:pointer;' class='active cpageval'><span style='cursor:pointer'> 
    $i</span></li>";
            } else {
                $msg .= "<li p='$i' class='inactive' ><span style='cursor:pointer'>$i</span></li>";
            }
        }
        // TO ENABLE THE NEXT BUTTON
        if ($next_btn && $cur_page < $no_of_paginations) {
            $nex = $cur_page + 1;
            $msg .= "<li p='$nex' class='inactive' style='cursor:pointer'><span style='cursor:pointer'> Next →</span></li>";
        } else if ($next_btn) {
            $msg .= "<li class='active' style='cursor:pointer'><span style='cursor:pointer'> Next → </span></li>";
        }
// TO ENABLE THE END BUTTON
        if ($last_btn && $cur_page < $no_of_paginations) {
            $msg .= "<li p='$no_of_paginations' class='inactive' style='cursor:pointer'><span style='cursor:pointer'>Last</span></li>";
        } else if ($last_btn) {
            $msg .= "<li p='$no_of_paginations' class='active' style='cursor:pointer'><span style='cursor:pointer'>Last</span></li>";
        }
        $msg = $msg . "</ul></div></div><div class='clearfix'></div>";
        return $msg;
    }
}

function paginationScript($pagename, $did = "1", $xdata = "") {
    ?>
    <script type="text/javascript">
        var el<?php echo $did; ?> = $("#<?php echo $did; ?>");
        var sort_type = "";
        function loadData<?php echo $did; ?>(page) {
            Apps.blockUI({target: el<?php echo $did; ?>.parent()});
            $.post("<?php echo $pagename; ?>?<?php echo $xdata; ?>", {page: page}, function (msg) {
                        Apps.unblockUI(el<?php echo $did; ?>.parent());
                        el<?php echo $did; ?>.html(msg);
                    });
                }

                function loadDataSort<?php echo $did; ?>(page, searchdata, sort_by) {
                    Apps.blockUI({target: el<?php echo $did; ?>.parent()});
                    $.post("<?php echo $pagename; ?>?sk=" + searchdata + "&<?php echo $xdata; ?>", {page: page, sort_by: sort_by}, function (msg) {
                        el<?php echo $did; ?>.html(msg);
                        $(".data .searchbox", el<?php echo $did; ?>).focus().val($(".searchbox", el<?php echo $did; ?>).val());
                        Apps.unblockUI(el<?php echo $did; ?>.parent());
                    });
                }

                $(document).ready(function () {
                    loadData<?php echo $did; ?>(1);
                    sort_type = "a2z";  // For first time page load default results
                    $('body').on('click', '#<?php echo $did; ?> .pagination li.inactive,#<?php echo $did; ?> .sort-menu li,#<?php echo $did; ?> .data .searchBtn ', function () {
                        if ($(this).hasClass("sort"))
                        {
                            sort_type = $(this).attr('sort');
                            loadDataSort<?php echo $did; ?>(1, $(".data .searchbox", el<?php echo $did; ?>).val(), sort_type);

                        } else
                        {
                            var page = ($(this).hasClass("searchBtn") == true) ? 1 : $(this).attr('p');
                            loadDataSort<?php echo $did; ?>(page, $(".data .searchbox", el<?php echo $did; ?>).val(), sort_type);
                        }
                    });

                    $(".data .searchbox", el<?php echo $did; ?>).on('keypress', function (e) {
                        if (e.which == 13)
                            $('.data .searchBtn', el<?php echo $did; ?>).click();

                    });
                });
                //*******************************************************
    </script>
    <?php
}

function front_paginationScript($pagename, $did = "1", $xdata = "") {
    ?>
    <script type="text/javascript">
        var el<?php echo $did; ?> = $("#<?php echo $did; ?>");
        var sort_type = "";
        function loadData<?php echo $did; ?>(page) {
            Main.blockUI({target: el<?php echo $did; ?>.parent()});
            $.post("<?php echo $pagename; ?>?<?php echo $xdata; ?>", {page: page}, function (msg) {
                        Main.unblockUI(el<?php echo $did; ?>.parent());
                        el<?php echo $did; ?>.html(msg);
                    });
                }

                function loadDataSort<?php echo $did; ?>(page, searchdata, sort_by) {
                    Apps.blockUI({target: el<?php echo $did; ?>.parent()});
                    $.post("<?php echo $pagename; ?>?sk=" + searchdata + "&<?php echo $xdata; ?>", {page: page, sort_by: sort_by}, function (msg) {
                        el<?php echo $did; ?>.html(msg);
                        $(".data .searchbox", el<?php echo $did; ?>).focus().val($(".searchbox", el<?php echo $did; ?>).val());
                        Apps.unblockUI(el<?php echo $did; ?>.parent());
                    });
                }

                $(document).ready(function () {
                    loadData<?php echo $did; ?>(1);
                    sort_type = "a2z";  // For first time page load default results
                    $('body').on('click', '#<?php echo $did; ?> .pagination li.inactive,#<?php echo $did; ?> .sort-menu li,#<?php echo $did; ?> .data .searchBtn ', function () {
                        if ($(this).hasClass("sort"))
                        {
                            sort_type = $(this).attr('sort');
                            loadDataSort<?php echo $did; ?>(1, $(".data .searchbox", el<?php echo $did; ?>).val(), sort_type);

                        } else
                        {
                            var page = ($(this).hasClass("searchBtn") == true) ? 1 : $(this).attr('p');
                            loadDataSort<?php echo $did; ?>(page, $(".data .searchbox", el<?php echo $did; ?>).val(), sort_type);
                        }
                    });

                    $(".data .searchbox", el<?php echo $did; ?>).on('keypress', function (e) {
                        if (e.which == 13)
                            $('.data .searchBtn', el<?php echo $did; ?>).click();

                    });
                });
                //*******************************************************
    </script>
    <?php
}

function pagination($pagename, $did = "1", $xdata = "") {
    ?>
    <script type="text/javascript">
        var el<?php echo $did; ?> = $("#<?php echo $did; ?>");
        var sort_type = "";
        function loadData<?php echo $did; ?>(page) {
            Apps.blockUI({target: el<?php echo $did; ?>.parent()});
            $.post("<?php echo $pagename; ?>?<?php echo $xdata; ?>", {page: page}, function (msg) {
                        Apps.unblockUI(el<?php echo $did; ?>.parent());
                        el<?php echo $did; ?>.html(msg);
                    });
                }

                function loadDataSort<?php echo $did; ?>(page, searchdata, sort_by) {
                    Apps.blockUI({target: el<?php echo $did; ?>.parent()});
                    $.post("<?php echo $pagename; ?>?sk=" + searchdata + "&<?php echo $xdata; ?>", {page: page, sort_by: sort_by}, function (msg) {
                        el<?php echo $did; ?>.html(msg);
                        $(".data .searchbox", el<?php echo $did; ?>).focus().val($(".searchbox", el<?php echo $did; ?>).val());
                        Apps.unblockUI(el<?php echo $did; ?>.parent());
                    });
                }

                $(document).ready(function () {
                    loadData<?php echo $did; ?>(1);
                    sort_type = "a2z";  // For first time page load default results
                    $('body').on('click', '#<?php echo $did; ?> .pagination li.inactive,#<?php echo $did; ?> .sort-menu li,#<?php echo $did; ?> .data .searchBtn ', function () {

                        if ($(this).hasClass("sort"))
                        {
                            sort_type = $(this).attr('sort');
                            loadDataSort<?php echo $did; ?>(1, $(".data .searchbox", el<?php echo $did; ?>).val(), sort_type);

                        } else
                        {
                            var page = ($(this).hasClass("searchBtn") == true) ? 1 : $(this).attr('p');
                            loadDataSort<?php echo $did; ?>(page, $(".data .searchbox", el<?php echo $did; ?>).val(), sort_type);
                        }
                    });

                    $(".data .searchbox", el<?php echo $did; ?>).on('keypress', function (e) {
                        if (e.which == 13)
                            $('.data .searchBtn', el<?php echo $did; ?>).click();

                    });


                });
                //*******************************************************
    </script>
    <?php
}
 function paginate($pagename, $pagetype, $did = "1", $sort = false) {
        ?>
       <!--  alert("sdfsd");return false; -->
        <script type="text/javascript">
            var el<?php echo $did; ?> = $("#<?php echo $did; ?>");
            var sort_type = "";
            function loadData<?php echo $did; ?>(page) {
                  //Apps.blockUI({target: el<?php echo $did; ?>.parent()});
                       $.post("<?php echo $pagename; ?>?type=<?php echo $pagetype; ?>", {page: page}, function(msg) {
                            el<?php echo $did; ?>.html(msg);
                              // Apps.unblockUI(el<?php echo $did; ?>.parent());
                          
                        });
                    }

                    function loadDataSort<?php echo $did; ?>(page, searchdata, sort_by) {
                          // Apps.blockUI(el<?php echo $did; ?>.parent());
                        $.post("<?php echo $pagename; ?>?type=<?php echo $pagetype; ?>&sk=" + searchdata, {page: page, sort_by: sort_by}, function(msg) {
                            el<?php echo $did; ?>.html(msg);
                            $(".data .searchbox", el<?php echo $did; ?>).focus().val($(".searchbox", el<?php echo $did; ?>).val());
                             //  Apps.unblockUI(el<?php echo $did; ?>.parent());
                           
                        });
                    }

                    $(document).ready(function() {
                        loadData<?php echo $did; ?>(1);
                        sort_type = "a2z";  // For first time page load default results

                       $('body').on('click', '#<?php echo $did; ?> .pagination li.inactive,#<?php echo $did; ?> .sort-menu li,#<?php echo $did; ?> .data .searchBtn ', function () {
                            if ($(this).hasClass("sort")) {
                                sort_type = $(this).attr('sort');
                                loadDataSort<?php echo $did; ?>(1, $(".data .searchbox", el<?php echo $did; ?>).val(), sort_type);
                            } else {
                                var page = ($(this).hasClass("searchBtn") == true) ? 1 : $(this).attr('p');
                                loadDataSort<?php echo $did; ?>(page, $(".data .searchbox", el<?php echo $did; ?>).val(), sort_type);
                            }
                        });

                        $("#<?php echo $did; ?>").on('keypress', ".data .searchbox", function(e) {

                            if (e.which == 13) {
                                $('.data .searchBtn', el<?php echo $did; ?>).click();
                            }

                        });
                        $("#<?php echo $did; ?>").on('submit', "form", function(e) {
                            e.preventDefault();
                        });
                    });
        </script>
        <?php
    }
 function paginate_main($pagename, $pagetype, $did = "1", $sort = false) {
        ?>
        <script type="text/javascript">
            var el<?php echo $did; ?> = $("#<?php echo $did; ?>");
            var sort_type = "";
            function loadData<?php echo $did; ?>(page) {
//                alert(<?php echo $did ?>);
//                return false;
                  //Apps.blockUI({target: el<?php echo $did; ?>.parent()});
                       $.post("<?php echo $pagename; ?>?type=<?php echo $pagetype; ?>", {page: page}, function(msg) {
                            el<?php echo $did; ?>.html(msg);
                              // Apps.unblockUI(el<?php echo $did; ?>.parent());
                        });
                    }

                    function loadDataSort<?php echo $did; ?>(page, searchdata, sort_by) {
                          // Apps.blockUI(el<?php echo $did; ?>.parent());
                        $.post("<?php echo $pagename; ?>?type=<?php echo $pagetype; ?>&sk=" + searchdata, {page: page, sort_by: sort_by}, function(msg) {
                            el<?php echo $did; ?>.html(msg);
                            $(".data .searchbox", el<?php echo $did; ?>).focus().val($(".searchbox", el<?php echo $did; ?>).val());
                             //  Apps.unblockUI(el<?php echo $did; ?>.parent());
                           
                        });
                    }

                    $(document).ready(function() {
                        loadData<?php echo $did; ?>(1);
                        sort_type = "a2z";  // For first time page load default results

                       $('body').on('click', '#<?php echo $did; ?>,#<?php echo $did; ?> .sort-menu li,#<?php echo $did; ?> .data .searchBtn ', function () {
                           alert('')
                            if ($(this).hasClass("sort")) {
                                sort_type = $(this).attr('sort');
                                loadDataSort<?php echo $did; ?>(1, $(".data .searchbox", el<?php echo $did; ?>).val(), sort_type);
                            } else {
                                var page = ($(this).hasClass("searchBtn") == true) ? 1 : $(this).attr('p');
                                loadDataSort<?php echo $did; ?>(page, $(".data .searchbox", el<?php echo $did; ?>).val(), sort_type);
                            }
                        });

                        $("#<?php echo $did; ?>").on('keypress', ".data .searchbox", function(e) {

                            if (e.which == 13) {
                                $('.data .searchBtn', el<?php echo $did; ?>).click();
                            }

                        });
                        $("#<?php echo $did; ?>").on('submit', "form", function(e) {
                            e.preventDefault();
                        });
                    });
        </script>
        <?php
    }
    /**********************************************************************/
    function front_paginate($pagename, $pagetype, $did = "1", $sort = false) {
       // print_r($pagename);exit;
        ?>
        <script type="text/javascript">
            var el<?php echo $did; ?> = $("#<?php echo $did; ?>");
            var sort_type = "";
            function loadData<?php echo $did; ?>(page) {
                  //Apps.blockUI({target: el<?php echo $did; ?>.parent()});
                       $.post("<?php echo $pagename; ?>?type=<?php echo $pagetype; ?>", {page: page}, function(msg) {
                            el<?php echo $did; ?>.html(msg);
                              // Apps.unblockUI(el<?php echo $did; ?>.parent());
                        });
                    }

                    function loadDataSort<?php echo $did; ?>(page, searchdata, sort_by) {
                          // Apps.blockUI(el<?php echo $did; ?>.parent());
                        $.post("<?php echo $pagename; ?>?type=<?php echo $pagetype; ?>&sk=" + searchdata, {page: page, sort_by: sort_by}, function(msg) {
                            el<?php echo $did; ?>.html(msg);
                            $(".data .searchbox", el<?php echo $did; ?>).focus().val($(".searchbox", el<?php echo $did; ?>).val());
                             //  Apps.unblockUI(el<?php echo $did; ?>.parent());
                           
                        });
                    }

                    $(document).ready(function() {
                        loadData<?php echo $did; ?>(1);
                        sort_type = "a2z";  // For first time page load default results

                       $('body').on('click', '#<?php echo $did; ?> .pagination li.inactive,#<?php echo $did; ?> .sort-menu li,#<?php echo $did; ?> .data .searchBtn ', function () {
                            if ($(this).hasClass("sort")) {
                                sort_type = $(this).attr('sort');
                                loadDataSort<?php echo $did; ?>(1, $(".data .searchbox", el<?php echo $did; ?>).val(), sort_type);
                            } else {
                                var page = ($(this).hasClass("searchBtn") == true) ? 1 : $(this).attr('p');
                                loadDataSort<?php echo $did; ?>(page, $(".data .searchbox", el<?php echo $did; ?>).val(), sort_type);
                            }
                        });

                        $("#<?php echo $did; ?>").on('keypress', ".data .searchbox", function(e) {

                            if (e.which == 13) {
                                $('.data .searchBtn', el<?php echo $did; ?>).click();
                            }

                        });
                        $("#<?php echo $did; ?>").on('submit', "form", function(e) {
                            e.preventDefault();
                        });
                    });
        </script>
        <?php
    }
function _encode($data) {
    return base64_encode($data);
}

function _decode($data) {
    return base64_decode($data);
}

/**
 * 
 * @param type $uconfig
 * file_name,path,type,prefix,width
 * @return boolean
 */
function uploadFile($uconfig) {
    $CI = & get_instance();
    $config['upload_path'] = $uconfig['path'];
    $config['allowed_types'] = $uconfig['type'];
    $config['max_size'] = '99999999';
    $config['max_width'] = 0;
    $config['max_height'] = 0;
//    $config['file_name'] = $uconfig['prefix'] . "_" . strtotime("now") . rand("10", "99");
    $config['file_name'] = $uconfig['prefix'] . "_" . $uconfig['fname'];
    $CI->load->library('upload', $config);
    if (!$CI->upload->do_upload($uconfig['file_name'])) {
        return true;
    } else {
        $data = $CI->upload->data();
        $org_wid = $data['image_width'];
        $org_ht = $data['image_height'];
        $file_name = explode(".", $data['file_name']);
        $config['image_library'] = 'gd2';
        $config['source_image'] = $data['full_path'];
        $config['create_thumb'] = FALSE;
        $config['maintain_ratio'] = TRUE;
        $config['width'] = $uconfig['width'];
        $height = intval(($config['width'] * $org_ht) / $org_wid);
        $config['height'] = $height;
        $CI->load->library('image_lib', $config);
        $CI->image_lib->resize();
        return $data['file_name'];
    }
}

function resizeFile($path, $width) {
    $CI = & get_instance();
    //$data = $CI->upload->data();
    $img_info = getimagesize($path);
    $org_wid = $img_info[0];
    $org_ht = $img_info[1];
    $config['file_name'] = basename($path);
    $config['image_library'] = 'gd2';
    $config['source_image'] = $path;
    $config['create_thumb'] = FALSE;
    $config['maintain_ratio'] = TRUE;
    $config['width'] = $width;
    $height = intval(($width * $org_ht) / $org_wid);
    $config['height'] = $height;
    $CI->load->library('image_lib', $config);
    $CI->image_lib->initialize($config);
    $CI->image_lib->resize();
    return basename($path);
}

/**
 * 
 * @param type $platform
 * @return string /
 */
function getDevicePlatform($platform) {
    $lplatform = strtolower($platform);
    if ($lplatform == "android" or $lplatform == "amazon") {
        return "A";
    } else if ($lplatform == "ios") {
        return "I";
    } else {
        return "O";
    }
}

function formatMobileNo($mobile) {
    if (is_numeric($mobile) && strlen($mobile) >= 10) {
        return substr($mobile, -10);
    }
    return FALSE;
}

function getDateDiff($start, $end) {
    $todate = strtotime($end);
    $fromdate = strtotime($start);
    $calculate_seconds = $todate - $fromdate; // Number of seconds between the two dates
    $days = floor($calculate_seconds / (24 * 60 * 60 )); // convert to days
    return $days;
}

function AddDays($date, $days, $op = "+") {
    return date('Y-m-d', strtotime($date . " $op $days days"));
}

function getDateRange($dt_from, $dt_to, $range = 10) {
    $dd = getDateDiff($dt_from, $dt_to);
    $gap_days = ceil($dd / $range);
    $dt_range['gap_days'] = $gap_days;
    $arr_date[] = $dt_to;
    for ($i = 1; $i < $range; $i++) {
        $ad_days = $gap_days * $i;
        $arr_date[] = AddDays($dt_to, $ad_days, "-");
    }
//    $dt_array = ;
    $dt_range['arr_date'] = array_reverse($arr_date);
    return $dt_range;
}

function getContent($url, $param = array()) {
    $postdata = http_build_query($param);
    $opts = array('http' =>
        array(
            'method' => 'POST',
            'header' => 'Content-type: application/x-www-form-urlencoded',
            'content' => $postdata
        )
    );
    $context = stream_context_create($opts);
    return file_get_contents($url, false, $context);
}

/**
 * 
 * @param type $device_reg_id
 * @return boolean
 * 
 */
function getID($device_reg_id) {

    $CI = &get_instance();
    $re = $CI->db->query("SELECT fk_reg_id FROM device_registration WHERE pk_device_reg_id='" . $device_reg_id . "'");
    $data = $re->result_array();
    if (count($data) > 0) {
        return $data[0]['fk_reg_id'];
    } else {
        return false;
    }
}

function createRefCode($id) {
    $year = date("y");
    $padded = str_pad($id, 10, "0", STR_PAD_LEFT);
    $text = substr($padded, -5);
    return $year . $text;
}

function dataToMail($data) {
    if (is_array($data)) {
        $data = serialize($data);
    }
    $CI = &get_instance();
    $CI->load->library('email');
    $config = getEmailConfig();
    $CI->email->initialize($config);
    $CI->email->from(ADMIN_EMAIL, "Digital ROTI");
    $CI->email->subject("Debug Data");
    $CI->email->message($data);
    $CI->email->to("sheetalkumar105@gmail.com");
    $CI->email->send();
}

function sendToMail($data) {

    if (is_array($data)) {
        $data = serialize($data);
    }
    $email_config = unserialize($data);
    $CI = &get_instance();
    $CI->load->library('email');
    $config = EmailConfig();
    $CI->email->initialize($config);
    $CI->email->from($email_config['eamilFrom'], "iAriv");
    $CI->email->subject($email_config['subject']);
    $CI->email->message($email_config['messagges']);
    $CI->email->to($email_config['emailTo']);
    $CI->email->send();
}

function getServingDDL($data) {
    ob_start();
    ?> 
    <div class="row blog-page" style="padding: 10px">
        <p><i class="fa fa-map-marker"></i> Contact No.: <?php echo $data['mobile_no'] ?></p>
        <?php if ($data['email_id']) { ?>
            <p><i class="fa fa-map-marker"></i> Email ID: <?php echo $data['email_id'] ?></p>
        <?php } ?>
    </div>
    <?php
    $output = ob_get_clean();
    return $output;
}

function longlattostatecity($lat, $long) {
    $api = "http://maps.googleapis.com/maps/api/geocode/json?latlng=" . $lat . "," . $long . "&sensor=true";
    $data = @file_get_contents($api);
    $city = "";
    $state = "";
    $country = "";
    $state_code = "";
    $country_code = "";
    if ($data != "") {
        $res = json_decode($data, true);
        $result = $res['results'];
        if (isset($result[0])) {
            foreach ($result as $res) {
                $address_componant = $res['address_components'];
                foreach ($address_componant as $ac) {
                    if (isset($ac['types'][0]) and $ac['types'][0] == "locality") {
                        $city = $ac['long_name'];
                    }
                    if (isset($ac['types'][0]) and $ac['types'][0] == "administrative_area_level_1") {
                        $state = $ac['long_name'];
                        $state_code = $ac['short_name'];
                    }
                    if (isset($ac['types'][0]) and $ac['types'][0] == "country") {
                        $country = $ac['long_name'];
                        $country_code = $ac['short_name'];
                    }
                }
            }
        }
    }
    return array(
        'city' => $city,
        'state' => $state,
        'state_code' => $state_code,
        'country' => $country,
        'country_code' => $country_code
    );
}

function removeDirectory($path) {
    $files = glob($path . '/*');
    foreach ($files as $file) {
        is_dir($file) ? removeDirectory($file) : unlink($file);
    }
    rmdir($path);
    return;
}

function random_key_string() {
    $source = bin2hex(openssl_random_pseudo_bytes(128));
    $string = '';
    $c = 0;
    while (strlen($string) < 32) {
        $dec = gmp_strval(gmp_init(substr($source, $c * 2, 2), 16), 10);
        if ($dec > 33 && $dec < 127 && $dec !== 39)
            $string .= chr($dec);
        $c++;
    }
    return $string;
}
function isPreview($uid,$tid,$layout=false){
  $url=NULL;
  if ($layout=='TRUE'):
      $url="public/storage/scene/".$uid."/".PARTIAL.$tid.PANO."pano360.html";
  else:
   if(!empty($uid) && !empty($tid) ) :
      $url="tour/preview/".$uid."/".$tid; 
   endif;
   endif;
   return $url;
}





function reamin_days($a,$b){
   // $a=2020-07-16;
 $e=strtotime($a);
$c=strtotime($b);
if($c >= $e) {
   $days='0';
} else {

    $count_days = date_diff(date_create($a), date_create($b));
    $days= $count_days->format("%a");
   
}

return $days;
}
function  uploadFileImgURL($destination,$imgUrl,$prefix=""){
     define('UPLOAD_DIR', $destination);
        $img = $imgUrl;
	$img = str_replace('data:image/jpeg;base64,', '', $img);
	$img = str_replace(' ', '+', $img);
	$data = base64_decode($img);
        $files=$prefix."_".uniqid() . '.jpg';
     	$file = UPLOAD_DIR .$files ;
     	$success = file_put_contents($file, $data);
        if($success):
        return $files;
         else:
            return false;
        endif;
	//print $success ? $file : 'Unable to save the file.';
}

function send_email($to,$subject,$message,$mail){
 
    $mail->IsSMTP(); 
      $mail->Host = HOST;   
     $mail->SMTPAuth = true;
     $mail->Username = FROM_EMAIL;  
     $mail->Password = FROM_PWD; 
     $mail->SMTPSecure = 'tls';
     $mail->Port = 25;
     $mail->From = FROM_EMAIL;
    $mail->FromName = SITE_NAME;
    $mail->AddAddress($to);
    $mail->IsHTML(true);     
    $mail->Subject = SITE_NAME .'-'.' '. $subject;
      $mail->Body    = $message;
      $mail->AddBCC(ADMIN_EMAIL); 
       if($mail->Send()){
            return true;
        }else{
            return false;
        }
      
}
